#!/bin/bash
set -u
project_dir=/root/autodl-tmp/repair-v8-batch1-20261019T011025Z
run_root=$project_dir/runs/repair-v8-qualification-20261018
export UV_CACHE_DIR=$project_dir/.cache/uv
export UV_DEFAULT_INDEX=https://pypi.tuna.tsinghua.edu.cn/simple
export UV_CONCURRENT_DOWNLOADS=4 UV_CONCURRENT_INSTALLS=1 UV_HTTP_TIMEOUT=300
export TMPDIR=$project_dir/.cache/tmp
mkdir -p "$TMPDIR"
uv_bin=/root/autodl-tmp/cuda-gemma4-llm/.cache/bin/uv
"$uv_bin" venv --python /root/miniconda3/bin/python3.12 "$run_root/venv" && "$uv_bin" pip sync --python "$run_root/venv/bin/python" --require-hashes "$project_dir/experiments/repair-v8-qualification.lock"
code=$?
printf '%s\n' "$code" > "$run_root/bootstrap/exit-code"
exit "$code"
